package com.example.gc.viewModels

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.example.gc.data.dao.ExerciseDaoImpl
import com.example.gc.data.network.RetrofitClient
import com.example.gc.data.repository.ExerciseRepository

class ExerciseViewModelFactory(
    private val baseUrl: String
) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(ExerciseViewModel::class.java)) {
            val retrofitClient = RetrofitClient(baseUrl)
            val daoImpl = ExerciseDaoImpl(retrofitClient.apiService)
            val repo = ExerciseRepository(daoImpl)
            @Suppress("UNCHECKED_CAST")
            return ExerciseViewModel(repo) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}