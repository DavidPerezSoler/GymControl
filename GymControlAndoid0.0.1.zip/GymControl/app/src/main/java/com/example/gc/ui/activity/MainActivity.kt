package com.example.gc.ui.activity

import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.gc.data.repository.ExerciseRepository
import com.example.gc.databinding.ActivityMainBinding
import com.example.gc.viewModels.ExerciseViewModel
import com.example.gc.viewModels.ExerciseViewModelFactory
import com.example.gc.ui.adapter.ExerciseAdapter


class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    private lateinit var vm: ExerciseViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        val factory = ExerciseViewModelFactory("http://192.168.1.100:50000/")
        vm = ViewModelProvider(this, factory)[ExerciseViewModel::class.java]

        binding.recyclerView.layoutManager = LinearLayoutManager(this)

        vm.state.observe(this) { state ->
            when (state) {
                is ExerciseRepository.UIState.Loading -> binding.progressBar.visibility = View.VISIBLE
                is ExerciseRepository.UIState.Success -> {
                    binding.progressBar.visibility = View.GONE
                    binding.recyclerView.adapter = ExerciseAdapter(state.data)
                }
                is ExerciseRepository.UIState.Error -> {
                    binding.progressBar.visibility = View.GONE
                    Toast.makeText(this, "", Toast.LENGTH_LONG).show()
                }
            }
        }

        vm.fetchExercise()
    }
}