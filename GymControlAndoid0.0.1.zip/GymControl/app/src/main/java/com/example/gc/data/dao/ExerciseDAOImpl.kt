package com.example.gc.data.dao

import com.example.gc.data.model.entity.Exercise
import com.example.gc.data.network.ExerciseApiService
import retrofit2.Response

class ExerciseDaoImpl(
    private val apiService: ExerciseApiService
) : ExerciseDAO {
    override suspend fun fetchAll(): Response<List<Exercise>> {
        return apiService.getExercises()
    }
}
