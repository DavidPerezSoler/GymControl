package com.example.gc.data.network

import com.example.gc.data.model.entity.Exercise
import retrofit2.Response
import retrofit2.http.GET

interface ExerciseApiService {
    @GET("api/Exercises")
    suspend fun getExercises(): Response<List<Exercise>>
}