package com.example.gc.viewModels

import androidx.lifecycle.*
import com.example.gc.data.dao.ExerciseDaoImpl
import com.example.gc.data.model.entity.Exercise
import com.example.gc.data.network.RetrofitClient
import com.example.gc.data.repository.ExerciseRepository
import kotlinx.coroutines.launch

class ExerciseViewModel(
    private val repository: ExerciseRepository
) : ViewModel() {

    private val _state = MutableLiveData<ExerciseRepository.UIState<List<Exercise>>>()
    val state: LiveData<ExerciseRepository.UIState<List<Exercise>>> = _state

    fun fetchExercise() {
        _state.value = ExerciseRepository.UIState.Loading
        viewModelScope.launch {
            _state.value = repository.getAllExercises()
        }
    }
}
