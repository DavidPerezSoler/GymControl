package com.example.gc.data.repository

import com.example.gc.data.dao.ExerciseDAO
import com.example.gc.data.model.entity.Exercise
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import retrofit2.Response

class ExerciseRepository(private val dao: ExerciseDAO) {

    sealed class UIState<out T> {
        data object Loading : UIState<Nothing>()
        data class Success<out T>(val data: T) : UIState<T>()
        data class Error(val msg: String) : UIState<Nothing>()
    }

    suspend fun getAllExercises(): UIState<List<Exercise>> = withContext(Dispatchers.IO) {
        try {
            val response: Response<List<Exercise>> = dao.fetchAll()
            if (response.isSuccessful) {
                UIState.Success(response.body() ?: emptyList())
            } else {
                UIState.Error("Error ${response.code()}: ${response.message()}")
            }
        } catch (e: Exception) {
            UIState.Error(e.localizedMessage ?: "Error desconocido")
        }
    }
}