package com.example.gc.ui.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.gc.R
import com.example.gc.data.model.entity.Exercise

class ExerciseAdapter(
    private val items: List<Exercise>
) : RecyclerView.Adapter<ExerciseAdapter.VH>() {

    inner class VH(view: View) : RecyclerView.ViewHolder(view) {
        private val tvName: TextView = view.findViewById(R.id.tvName)
        private val tvCategory: TextView = view.findViewById(R.id.tvCategory)
        fun bind(e: Exercise) {
            tvName.text = e.name
            tvCategory.text = e.category
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH =
        VH(LayoutInflater.from(parent.context)
            .inflate(R.layout.item_exercise, parent, false))

    override fun onBindViewHolder(holder: VH, position: Int) =
        holder.bind(items[position])

    override fun getItemCount(): Int = items.size
}