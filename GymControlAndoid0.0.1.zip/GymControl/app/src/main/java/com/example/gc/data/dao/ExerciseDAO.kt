package com.example.gc.data.dao

import com.example.gc.data.model.entity.Exercise
import retrofit2.Response

interface ExerciseDAO {
    suspend fun fetchAll(): Response<List<Exercise>>
}